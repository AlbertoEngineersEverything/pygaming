
class Foo(object):
	
	def bar(self):
		print "bar"
		
foo = Foo()
foo.bar()