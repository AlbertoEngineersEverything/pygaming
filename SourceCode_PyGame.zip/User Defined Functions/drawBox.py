#!/usr/bin/python

# draw box example

def drawBox():
	print "+--------+"
	print "|        |"
	print "+--------+"
	

drawBox()
print "Between two boxes"
drawBox()