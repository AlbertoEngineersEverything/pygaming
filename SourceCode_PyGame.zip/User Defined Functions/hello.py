#!/usr/bin/python

def sayHello():
	print "Hello, world!"
	
sayHello()