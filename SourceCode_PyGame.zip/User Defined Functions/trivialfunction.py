#!/usr/bin/python

def add(num1, num2):
	return num1 + num2
	

print add(10, 5)
print add('sloan ', 'kelly')
print add(3.14, 1.61)
print add((1,2,3), (4,5,6))